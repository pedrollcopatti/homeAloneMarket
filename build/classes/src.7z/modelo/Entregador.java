package modelo;

import java.util.ArrayList;

/**
 * @author Guilherme
 */
public class Entregador extends Usuario {

    public Entregador(String nome, long cpfCpnj, String senha) {
        super(nome, cpfCpnj, senha);
    }

    @Override
    public String toString() {
        return super.toString() + "Cadastrado como Entregador";
    }

    public ArrayList<Orcamento> getOrcamentos() {
        return (ArrayList<Orcamento>) getOrcamentos().stream()
                                                     .filter(orcamento -> orcamento.getEntregador().equals(this));
    }

}
