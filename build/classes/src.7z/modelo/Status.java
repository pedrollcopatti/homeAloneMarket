package modelo;

/**
 * @author Guilherme
 */
public enum Status {
    Processando, Enviado, AguardandoPagamento, Cancelada, Concluida;
}
