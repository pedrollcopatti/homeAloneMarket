package modelo;

/**
 * @author Guilherme
 */
public enum Bandeira {
    Visa, MasterCard, Elo;
}
