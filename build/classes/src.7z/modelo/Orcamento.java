package modelo;

/**
 * @author Guilherme
 */
public class Orcamento {

    private int id;
    private double valorTotal;
    private double valorBruto;
    private double valorDesconto;
    private Pagamento pagto;
    private Entregador entregador;

    public Orcamento(double valorBruto, double valorDesconto) {
        this.valorBruto = valorBruto;
        this.valorDesconto = valorDesconto;
        this.valorTotal = valorBruto - valorDesconto;
        this.pagto = null;
        this.entregador = null;
    }

    public int getId() {
        return id;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public double getValorBruto() {
        return valorBruto;
    }

    public double getValorDesconto() {
        return valorDesconto;
    }
    
    public Pagamento getPagamento() {
        return pagto;
    }

    public boolean pagar(MetodoPagamento metodoPagto) {
        if (metodoPagto == null) {
            return false;
        }
        this.pagto = new Pagamento(valorTotal, metodoPagto);
        return true;
    }

    public boolean adicionaEntregador(Entregador entregador) {
        if (entregador == null)
            return false;
        this.entregador = entregador; 
        return true;
    }

    public Entregador getEntregador() {
        return entregador;
    }
    
    
}
