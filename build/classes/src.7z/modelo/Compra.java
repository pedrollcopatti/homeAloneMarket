package modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 * @author Guilherme
 */
public class Compra {

    private long id;
    private Date dataEntrega;
    private Date dataPrevisao;
    private Status status;
    private ArrayList<Orcamento> orcamentos;
    private ArrayList<Produto> produtos;

    public Compra(Date dataPrevisao) {
        this.dataPrevisao = dataPrevisao;
        this.dataEntrega = null;
        this.status = Status.Processando;
        this.orcamentos = new ArrayList<Orcamento>();
        this.produtos = new ArrayList<Produto>();
    }

    public long getId() {
        return id;
    }

    public Date getDataEntrega() {
        return dataEntrega;
    }

    public Date getDataPrevisao() {
        return dataPrevisao;
    }

    public Status getStatus() {
        return status;
    }

    public boolean adicionaOrcamento(Orcamento orcamento) {
        if (orcamento == null) {
            return false;
        }
        this.orcamentos.add(orcamento);
        return true;
    }

    public boolean adicionaProduto(Produto produto) {
        if (produto == null) {
            return false;
        }
        this.produtos.add(produto);
        return true;
    }

    public void deletaProduto(Produto produto) {
        produtos.remove(produto);
    }

    public Pagamento getPagamento() {
        for (Orcamento orcamento : orcamentos) {
            if (orcamento.getPagamento() != null) {
                return orcamento.getPagamento();
            }
        }
        return null;
    }

    public ArrayList<Produto> getProduto() {
        return produtos;
    }

    public Produto getProduto(String nome) {
        for (Produto produto : produtos) {
            if (produto.getNome().equals(nome)) {
                return produto;
            }
        }
        return null;
    }

    public Produto getProduto(int id) {
        return produtos.get(id);
    }

    public void setDataEntrega(Date dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public void setDataPrevisao(Date dataPrevisao) {
        this.dataPrevisao = dataPrevisao;
    }

}
